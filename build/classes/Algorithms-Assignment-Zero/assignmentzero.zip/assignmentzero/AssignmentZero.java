/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignmentzero;

/**
 *
 * @author Reed
 */
public class AssignmentZero
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        DubRandArray a = new DubRandArray(2000);
        
        double temp[] = a.sort();
        
        int i = 1;
        for(double ex : temp){
            String post = String.valueOf(i) + " :: " + String.valueOf(ex);
            System.out.println(post);
            i++;
        }
    }
    
}
