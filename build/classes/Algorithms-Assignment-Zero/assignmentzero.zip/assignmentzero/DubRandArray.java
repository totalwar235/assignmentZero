/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignmentzero;

import java.util.Random;

/**
 *
 * @author Reed
 */
public class DubRandArray
{

    private double arr[];

    DubRandArray(int x)
    {
        double temp[] = new double[x];
        int i = 0;
        for (Double ex : temp) {
            Random insert = new Random();
            temp[i] = insert.nextDouble();
            i++;
        }
        arr = temp;
    }

    /**
     *
     * @return a selection sorted array of doubles
     */
    public double[] sort()
    {
        double sorted[] = arr;

        int i, j, first;
        double temp;
        for (i = sorted.length - 1; i > 0; i--) {
            first = 0;   //initialize to subscript of first element
            for (j = 1; j <= i; j++) //locate smallest element between positions 1 and i.
            {
                if (sorted[j] < sorted[first]) {
                    first = j;
                }
            }
            temp = sorted[first];   //swap smallest found with element in position i.
            sorted[first] = sorted[i];
            sorted[i] = temp;
        }

        return sorted;
    }

    public double[] getArr()
    {
        return arr;
    }

    public void setArr(double temp[])
    {
        arr = temp;
    }
}
